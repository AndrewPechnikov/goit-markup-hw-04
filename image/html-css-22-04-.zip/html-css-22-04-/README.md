# html-css-22

- QnA
- Разбор страницы "Портфолио"
- [System Font Stack](https://systemfontstack.com/) и [это](https://devhints.io/css-system-font-stack)
- Практика: шрифты и оформление текста
